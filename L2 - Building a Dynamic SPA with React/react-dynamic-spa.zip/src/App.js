import React, { useState } from "react";

function App() {
  const [page, setPage] = useState("Home");

  const renderContent = () => {
    switch (page) {
      case "Home":
        return <h1 style={{ color: "green" }}>Welcome to Home</h1>;
      case "About":
        return <h1 style={{ color: "blue" }}>About Us</h1>;
      case "Contact":
        return <h1 style={{ color: "purple" }}>Contact Us</h1>;
      default:
        return <h1>Page Not Found</h1>;
    }
  };

  return (
    <div>
      <nav style={{ display: "flex", gap: "20px", marginBottom: "20px" }}>
        <button onClick={() => setPage("Home")}>Home</button>
        <button onClick={() => setPage("About")}>About</button>
        <button onClick={() => setPage("Contact")}>Contact</button>
      </nav>
      <div>{renderContent()}</div>
    </div>
  );
}

export default App;
