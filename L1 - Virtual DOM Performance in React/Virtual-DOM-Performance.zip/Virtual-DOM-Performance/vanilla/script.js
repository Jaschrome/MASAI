
let domUpdateCount = 0;
function changeTitle() {
  const newTitle = "Vanilla Title " + (domUpdateCount + 1);
  document.title = newTitle;
  document.getElementById("title").textContent = newTitle;
  domUpdateCount++;
  document.getElementById("counter").textContent = domUpdateCount;
}
