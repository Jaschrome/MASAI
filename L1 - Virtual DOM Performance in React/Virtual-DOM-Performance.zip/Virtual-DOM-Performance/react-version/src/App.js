
import React, { useState } from "react";

function App() {
  const [count, setCount] = useState(0);

  const changeTitle = () => {
    const newTitle = "React Title " + (count + 1);
    document.title = newTitle;
    setCount(count + 1);
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>React DOM Title</h1>
      <p>DOM Updates: {count}</p>
      <button onClick={changeTitle}>Change Title (React)</button>
    </div>
  );
}

export default App;
